package adt;

public interface ListADT<T> {

	
	
}
